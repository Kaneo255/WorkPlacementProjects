/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package studentservices;

/**
 *
 * @author James Cosgrave
 */
public class User {

    public User(String fname1, String lname1, String uname1, String pword1) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Object getUsername() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Object getPassword() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}

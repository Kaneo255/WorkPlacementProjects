/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package computingsupport;

/**
 *
 * @author James Cosgrave
 */
class StudentForm {

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}
